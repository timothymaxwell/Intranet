<?php
// Initialize the session
session_start();
 
// Check if the user is logged in, if not then redirect him to login page
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
    header("location: index.php");
    exit;
}
?>
 
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Welcome</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.css">
    <link rel="stylesheet">
	<style type="text/css">
        body{ font: 14px sans-serif; text-align: center; }
		#weather{ width: 370px; height:400px; padding: 20px;}
    </style>
</head>
<head>
		<div id='background'><img src="images/bannerBG.png" alt="Background"></div>
		<meta charset="utf-8">
		<meta name="viewport" content+"width=device-width, initial-scale=1">
		<link rel="stylesheet" type="text/css" href="intranet.css">
		<script src="intranet.js"></script> 
		<title>Lotustar Financial Intranet</title>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="stylesheet" href="banner.css" />
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
	</head>
	
	<body>
	    <div class='bannerBox'>
            <div id='bannerLogo'>
				<img src="images/bannerLogo.png" alt="Lotustar Financial Logo" width="120" height="120" z-index="-1">
			</div>
            <div class='bannerInfo'>
                <font color="white"> Lotustar Financial PTY LTD T/A <br> Lotustar Financial is a Corporate Authorised Representative of Bluewater Financial Advisors PTY LTD <br> ABN 99 153 118 533 <br> AFS License No. 411846 <br> GPO Box 4523 Sydney NSW 2000 <br> V1: 06082019 </font>
            </div>
            <div class='contactInfo'>
                <font color="blue"> Address: Southport Central Tower 3, <br> Level 10, 9 Lawson Street Southport <br> QLD 4215 <br> Telephone: 07 5560 3431 <br> E-mail: admin@lotustar.com.au </font>
            </div>
    <div class="page-header">
        <h1>Hi, <b><?php echo htmlspecialchars($_SESSION["username"]); ?></b>. Welcome to the Lotusstar Intranet.</h1>
    </div>
    <p>
    </p>
		</div>
		<div id="log">
			<a href="reset-password.php" class="btn btn-warning">Reset Your Password</a>
			<a href="logout.php" class="btn btn-danger">Sign Out of Your Account</a>
		</div>
		<br>
		<br>
		<p>
		
			<!-- Slidowshow -->
			<div id="slideshow">
				<div>
					<img src="//farm6.static.flickr.com/5224/5658667829_2bb7d42a9c_m.jpg">
				</div>
			<div>
				<img src="//farm6.static.flickr.com/5230/5638093881_a791e4f819_m.jpg">
			</div>
			<div>
				Pretty cool eh? This slide is proof the content can be anything.
			</div>
			</div>
		</p>
<!-------------------------------- WEATHER ------------->		
	<div class="container">
		<div id="weather">
			<h1>
					Weather Forecast -->
		<div id="weather">
			<a class="weatherwidget-io" href="https://forecast7.com/en/n28d02153d40/gold-coast/" data-label_1="GOLD COAST" data-label_2="WEATHER" data-theme="original" >GOLD COAST WEATHER</a>
			<script>
				!function(d,s,id){var js,fjs=d.getElementsByTagName(s)[0];if(!d.getElementById(id)){js=d.createElement(s);js.id=id;js.src='https://weatherwidget.io/js/widget.min.js';fjs.parentNode.insertBefore(js,fjs);}}(document,'script','weatherwidget-io-js');
			</script>
			<a class="weatherwidget-io" href="https://forecast7.com/en/37d23n80d41/blacksburg/" data-label_1="BLACKSBURG" data-label_2="WEATHER" data-theme="original" >BLACKSBURG WEATHER</a>
			<script>
				!function(d,s,id){var js,fjs=d.getElementsByTagName(s)[0];if(!d.getElementById(id)){js=d.createElement(s);js.id=id;js.src='https://weatherwidget.io/js/widget.min.js';fjs.parentNode.insertBefore(js,fjs);}}(document,'script','weatherwidget-io-js');
			</script>
			<a class="weatherwidget-io" href="https://forecast7.com/en/39d74n104d99/denver/" data-label_1="DENVER" data-label_2="WEATHER" data-theme="original" >DENVER WEATHER</a>
			<script>
				!function(d,s,id){var js,fjs=d.getElementsByTagName(s)[0];if(!d.getElementById(id)){js=d.createElement(s);js.id=id;js.src='https://weatherwidget.io/js/widget.min.js';fjs.parentNode.insertBefore(js,fjs);}}(document,'script','weatherwidget-io-js');
			</script>
			<a class="weatherwidget-io" href="https://forecast7.com/en/52d374d90/amsterdam/" data-label_1="AMSTERDAM" data-label_2="WEATHER" data-theme="original" >AMSTERDAM WEATHER</a>
			<script>
				!function(d,s,id){var js,fjs=d.getElementsByTagName(s)[0];if(!d.getElementById(id)){js=d.createElement(s);js.id=id;js.src='https://weatherwidget.io/js/widget.min.js';fjs.parentNode.insertBefore(js,fjs);}}(document,'script','weatherwidget-io-js');
			</script>
			<a class="weatherwidget-io" href="https://forecast7.com/en/14d61121d02/metro-manila/" data-label_1="MANILA" data-label_2="WEATHER" data-theme="original" >MANILA WEATHER</a>
			<script>
				!function(d,s,id){var js,fjs=d.getElementsByTagName(s)[0];if(!d.getElementById(id)){js=d.createElement(s);js.id=id;js.src='https://weatherwidget.io/js/widget.min.js';fjs.parentNode.insertBefore(js,fjs);}}(document,'script','weatherwidget-io-js');
			</script>
		</div>
 <!--	Landscapes -->		
		<br>
<!-- Client update -->
<div class="wrapper-editor">

  <div class="d-flex justify-content-center buttons-wrapper">
    <button id="" class="btn btn-sm btn-teal btn-rounded addNewColumn">Activate edits</button>
    <button id="" class="btn btn-sm btn-mdb-color btn-rounded removeColumns" disabled>Deactivate edits</button>
    <button id="" class="btn btn-sm btn-info btn-rounded addNewRows">Add new rows</button>
  </div>

  <div class="closeByClick d-none"></div>

  <div class="showForm d-none" style="position: fixed; top: 20%; left:50%; transform: translate(-50%, -50%); z-index: 1100;">

    <form class="text-center border border-light p-5" style="background: white;">

      <button type="button" class="close position-relative button-x" style="top:-12%; right: -5%">
        <span aria-hidden="true" class="text-danger">×</span>
      </button>

      <h3 class="h3 my-3 text-danger font-weight-bold">Delete</h3>

      <hr class="mt-2 mb-3">

      <p class="text-center h5 py-2 pb-3">Are you sure to delete selected rows?</p>

      <hr class="mt-2 mb-3">

      <div class="d-flex justify-content-center buttonYesNoWrapper">
        <button type="button" class="btn btn-danger btnYes btn-sm">Yes</button>
        <button type="button" class="btn btn-primary btnNo btn-sm">No</button>
      </div>
    </form>

  </div>

  <table id="dtBasicExample-1" class="table table-striped table-bordered" cellspacing="0" width="100%">
    <thead>
      <tr>
        <th class="th-sm">Name

        </th>
        <th class="th-sm">Position

        </th>
        <th class="th-sm">Office

        </th>
        <th class="th-sm">Age

        </th>
        <th class="th-sm">Start date

        </th>
        <th class="th-sm">Salary

        </th>
      </tr>
    </thead>
    <tbody>
	</tbody>
	<tfoot>
	</tfoot>
  </table>

	<script $('#dtBasicExample-1').mdbEditor({
		rowEditor: true
		});
		$('.dataTables_length').addClass('bs-select');
	</script>

</div>
<!-- Editable table -->
		
		<!--
		Equity Builder and Super Leaver Calculators
		-->
		<h2>Home Loan Information </h2>
<body>
  <table class="editabletable" border="1">
    <tr>
      <td><div contenteditable>a</div></td>
      <td><div contenteditable>b</div></td>
      <td><div contenteditable>c</div></td>
    </tr>
    <tr>
      <td><div contenteditable>d</div></td>
      <td><div contenteditable>e</div></td>
      <td><div contenteditable>f</div></td>
    </tr>
    <tr>
      <td><div contenteditable>g</div></td>
      <td><div contenteditable>h</div></td>
      <td><div contenteditable>i</div></td>
    </tr>
  </table>
</body>
		Hyperlinks
		<a href="https://www.aia.com.au/AdviserSite/responsehandler?TAM_OP=login&USERNAME=unauthenticated&ERROR_CODE=0x00000000 ">AIA</a>
		<a href="https://www.asx.com.au/">ASX</a>
		<a href="https://portal.amp.com.au/wps/portal/opp">AMP</a>
		<a href="https://www.optussmartpay.com/access/index.aspx?a=84435932&dl=RBA_ATO">ATO</a>
		<a href="https://www.optussmartpay.com/access/index.aspx?a=84435932&dl=RBA_ATO">BOM</a>
		<a href="https://www.optussmartpay.com/access/index.aspx?a=84435932&dl=RBA_ATO ">Clearview</a>
		<a href="https://www.portfolioonline.com.au/displayLogin.s">IOOF</a>
		<a href="https://www.mlc.com.au/adviser/home">MLC</a>
		<a href="https://adviser.tal.com.au/?ReturnUrl=%2fHome%2fWelcome">TAL</a>
		<a href="https://www.hub24.com.au/ ">HUB24</a>
		<a href="https://app.hellosign.com/account/logIn">Hellosign</a>
		<a href="http://www.bluewaterfinancial.com.au">Bluewater</a>
		<a href="https://www.onepath.com.au/adviser/AdviserAdvantage/adviser-login.aspx">Onepath</a>
		<a href="https://seido.ytml.com.au/home">Onepath</a>
		<a href="https://neoslife.com.au/adviser">Neos</a>
		<a href="https://www.pdf2go.com/">Edit pdf</a>
		<a href="https://epr.onepath.com.au/epr/BrokerLogon.aspx"></a>
		
		
		
		Hyperlinks to the server
		

		<!--
		Current Fum
		-->
		<div id="FUM">
			<h2>Finances Under Management
			
			<form action="/action_page.php">
				FUM CURRENT:<br>
				<input type="text" name="fumCurrent" value="$3,000,000">
			<br>
				FUM GOAL:<br>
				<input type="text" name="fumGoal" value="$3,100,000">
				<br><br>
				<input type="submit" value="Submit">
			</form>
			<br>
		</div>
		
		

		<div class="footer">
			<!-- TradingView Widget BEGIN -->
<div class="tradingview-widget-container">
  <div class="tradingview-widget-container__widget"></div>
  <div class="tradingview-widget-copyright"><a href="https://www.tradingview.com" rel="noopener" target="_blank"></div>
  <script type="text/javascript" src="https://s3.tradingview.com/external-embedding/embed-widget-ticker-tape.js" async>
  {
  "symbols": [
    {
      "title": "S&P 500",
      "proName": "OANDA:SPX500USD"
    },
    {
      "title": "Nasdaq 100",
      "proName": "OANDA:NAS100USD"
    },
    {
      "description": "ASX",
      "proName": "ASX:ASX"
    },
    {
      "description": "AUD/USD",
      "proName": "OANDA:AUDUSD"
    },
    {
      "description": "AUD/EUR",
      "proName": "FX_IDC:AUDEUR"
    },
    {
      "description": "AUD/GBP",
      "proName": "FX_IDC:AUDGBP"
    },
    {
      "description": "NAB",
      "proName": "ASX:NAB"
    },
    {
      "description": "CBA",
      "proName": "ASX:CBA"
    },
    {
      "description": "WBC",
      "proName": "ASX:WBC"
    },
    {
      "description": "ANZ",
      "proName": "ASX:ANZ"
    },
    {
      "description": "RIO",
      "proName": "ASX:RIO"
    },
    {
      "description": "AMP",
      "proName": "ASX:AMP"
    },
    {
      "description": "BHP",
      "proName": "ASX:BHP"
    },
    {
      "description": "MCQ",
      "proName": "ASX:MQG"
    }
  ],
  "colorTheme": "light",
  "isTransparent": false,
  "displayMode": "adaptive",
  "locale": "en"
}
  </script>
</div>
<!-- TradingView Widget END -->
		</div>
		<!--
		KPI
		-->
	</div>
</body>
</html>