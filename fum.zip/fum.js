function saveCookies()
{
	localStorage._numberOfClients = document.getElementById("numberOfClients").value;
	localStorage._date = document.getElementById("date").value;
	localStorage._targetClients = document.getElementById("targetClients").value;
	localStorage._reward = document.getElementById("reward").value;
	localStorage._goal = document.getElementById("goal").value;
}
	
function loadCookies()
{
	document.getElementById("numberOfClients").value = localStorage._numberOfClients;
	document.getElementById("date").value = localStorage._date;
	document.getElementById("targetClients").value = localStorage._targetClients;
	document.getElementById("reward").value = localStorage._reward;
	document.getElementById("goal").value = localStorage._goal;
	document.getElementById("displayNoc").innerhtml = localStorage._numberOfClients;
	document.getElementById("displayDate").innerhtml = localStorage._date;
	document.getElementById("displayTargetClients").innerhtml = localStorage._date;
	document.getElementById("displayReward").innerhtml = localStorage._date;
	document.getElementById("displayGoal").innerhtml = localStorage._date;
}