<!DOCTYPE html>
<html lang="en">
	
	<?php
		session_start();
			if (!isset($SESSION['loggedin']) || $_SESSION['loggedin'] == false) {
			header("Location; index.php");
		}
	?>
		
	<head>
		<meta charset="utf-8">
		<meta name="viewport" content+"width=device-width, initial-scale=1">
		<link rel="stylesheet" type="text/css" href="intranet.css">
		<link rel="stylesheet" type="text/css" href="banner.css">
		<script src="intranet.js"></script> 
		<title>Lotustar Financial Intranet</title>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="stylesheet" href="style.css" />
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
	</head>
	
	<body>
	    <div class='bannerBox'>
            <div id='bannerLogo'>
				<img src="images/bannerLogo.png" alt="Lotustar Financial Logo" width="120" height="120" z-index="1">
			</div>
            <div class='bannerInfo'>
                <font color="white"> Lotustar Financial PTY LTD T/A <br> Lotustar Financial is a Corporate Authorised Representative of Bluewater Financial Advisors PTY LTD <br> ABN 99 153 118 533 <br> AFS License No. 411846 <br> GPO Box 4523 Sydney NSW 2000 <br> V1: 06082019 </font>
            </div>
            <div class='contactInfo'>
                <font color="blue"> Address: Southport Central Tower 3, <br> Level 10, 9 Lawson Street Southport <br> QLD 4215 <br> Telephone: 07 5560 3431 <br> E-mail: admin@lotustar.com.au </font>
            </div>
		</div>
		<br>
		<br>
	<div class="container">
		<div id="weather">
			<h1>
				Weather
				<div id="temp"></div>
				<div id="minutely"></div>
			</h1>
			<h2><div id="location"></div></h2>
			<script src=app.js"></script>
		</div>
 <!--	Landscapes -->		
		
		<!--
		Equity Builder and Super Leaver Calculators
		
		Hyperlinks
		
		Hyperlinks to the server
		
		Weather Forecast
		
		Current Fum
		-->
		
		<div id="FUM">
			<h2>Finances Under Management
			
			<form action="/action_page.php">
				FUM CURRENT:<br>
				<input type="text" name="fumCurrent" value="$3,000,000">
			<br>
				FUM GOAL:<br>
				<input type="text" name="fumGoal" value="$3,100,000">
				<br><br>
				<input type="submit" value="Submit">
			</form>
			<br>
		</div>
		
		

		<div class="footer">
			<!-- TradingView Widget BEGIN -->
<div class="tradingview-widget-container">
  <div class="tradingview-widget-container__widget"></div>
  <div class="tradingview-widget-copyright"><a href="https://www.tradingview.com" rel="noopener" target="_blank"></div>
  <script type="text/javascript" src="https://s3.tradingview.com/external-embedding/embed-widget-ticker-tape.js" async>
  {
  "symbols": [
    {
      "title": "S&P 500",
      "proName": "OANDA:SPX500USD"
    },
    {
      "title": "Nasdaq 100",
      "proName": "OANDA:NAS100USD"
    },
    {
      "description": "ASX",
      "proName": "ASX:ASX"
    },
    {
      "description": "AUD/USD",
      "proName": "OANDA:AUDUSD"
    },
    {
      "description": "AUD/EUR",
      "proName": "FX_IDC:AUDEUR"
    },
    {
      "description": "AUD/GBP",
      "proName": "FX_IDC:AUDGBP"
    },
    {
      "description": "NAB",
      "proName": "ASX:NAB"
    },
    {
      "description": "CBA",
      "proName": "ASX:CBA"
    },
    {
      "description": "WBC",
      "proName": "ASX:WBC"
    },
    {
      "description": "ANZ",
      "proName": "ASX:ANZ"
    },
    {
      "description": "RIO",
      "proName": "ASX:RIO"
    },
    {
      "description": "AMP",
      "proName": "ASX:AMP"
    },
    {
      "description": "BHP",
      "proName": "ASX:BHP"
    },
    {
      "description": "MCQ",
      "proName": "ASX:MQG"
    }
  ],
  "colorTheme": "light",
  "isTransparent": false,
  "displayMode": "adaptive",
  "locale": "en"
}
  </script>
</div>
<!-- TradingView Widget END -->
		</div>
		<!--
		KPI
		-->
	</div>
	</body>
<body>