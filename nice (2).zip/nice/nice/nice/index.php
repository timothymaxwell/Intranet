 <!DOCTYPE html>
 <html lang="en">
	<head>
		<!-- Title -->
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<title>Intranet - Login</title>
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<script src="intranet.js"></script> 
		<title>Lotustar Financial Intranet</title>
		<link rel="stylesheet" href="index.css" />
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
	</head>
	
		<body>
			<?php
				session_start();
				
				$username = "user";
				$password = "password";
				
				if (isset($_SESSION['loggedin']) && $_SESSION['logged_in'] == true) {
					header("Location: intranet.php");
				}
				
				if (isset($_POST['username']) && isset($_POST['password'])) {
					if ($_POST['username'] == $username && $_POST['password'] == $password)
				{
						$_SESSION['loggedin']=true;
						header("Location: intranet.php");
					}
					
				}
		    ?>
			<div class='bannerBox'>
				<div id='bannerLogo'>
					<img src="images/bannerLogo.png" alt="Lotustar Financial Logo">
				</div>
				<div class='bannerInfo'>
					<font color="white"> Lotustar Financial PTY LTD T/A <br> Lotustar Financial is a Corporate Authorised Representative of Bluewater Financial Advisors PTY LTD <br> ABN 99 153 118 533 <br> AFS License No. 411846 <br> GPO Box 4523 Sydney NSW 2000 <br> V1: 06082019 </font>
				</div>
				<div class='contactInfo'>
					<font color="blue"> Address: Southport Central Tower 3, <br> Level 10, 9 Lawson Street Southport <br> QLD 4215 <br> Telephone: 07 5560 3431 <br> E-mail: admin@lotustar.com.au</font>
				</div>
			</div>
			
			<br>
			<br>
			
			<form method="post" action="intranet.php>			
					<label for="uname"><b>Username<b></label>
					<input type="text" placeholder="Enter Username" name="uname" required>
					<label for="psw"><b>Password</b></label>
					<input type="password" placeholder="Enter Password" name="psw" required>
					<input type="submit" value="Login">
		
					<label id"remember">
						<input type="checkbox" checked="checked" name="remember"> Remember me
					</label>
			</form>
					<div id='psw'>Forgot&nbsp;<a href="#" id="psw">Password?</a>
			</div>
		</body>
		
</html>