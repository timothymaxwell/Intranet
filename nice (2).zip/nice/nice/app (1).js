function weather() {
	var location = document.getElementById("location");
	var apiKey = 310jsndk;
	var url = "https://api.forecast.io/forecast/";
	
	navigator.geolocation.getCurrentPosition(success, error);
	
	function success(position) {
		latitude = position.coords.latitude;
		longitude = position.coords.longitude;
		
		location.innerHTML=
		"latitude is " + latitude + "Longitude is " + longitude + "o",
		
		$.getJSON(
		url + apikey + "/" + "," + longitude + "?callback=?",
		function(data) {
			$("#temp").html(data.currently.temperature + "F");
			$("minutely").html(data.minutely.summary);
		}
	);
	}

	function error() {
		location.innerHTML = "Unable to retrieve your location";
	}
	
	location.innerHTML = "Locatining...";
}

weather();