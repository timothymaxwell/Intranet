$('#dtBasicExample').mdbEditor({
headerLength: 6,
evenTextColor: '#000',
oddTextColor: '#000',
bgEvenColor: '',
bgOddColor: '',
thText: '',
thBg: '',
modalEditor: false,
bubbleEditor: false,
contentEditor: false,
rowEditor: false
});

$('#dtBasicExample').mdbEditor({
mdbEditor: true
});
$('.dataTables_length').addClass('bs-select');