$('#dtBasicExample-1').mdbEditor({
rowEditor: true
});
$('.dataTables_length').addClass('bs-select');