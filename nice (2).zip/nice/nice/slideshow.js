// Declare variables and execute function
var autoSlideIndex = 0;
showSlides();

//Define function
function showSlides() {
  var i;
  var autoSlides = document.getElementsByClassName("mySlides");
  for (i = 0; i < autoSlides.length; i++) {
    autoSlides[i].style.display = "none";
  }
  autoSlideIndex++;
  if (autoSlideIndex > autoSlides.length) {autoSlideIndex = 1}
  autoSlides[autoSlideIndex-1].style.display = "block";
  setInterval(showSlides, 10000); // Change image every 2 seconds
} 

var slideIndex = 1;
showoffSlides(slideIndex);

// Next/previous controls
function plusSlides(n) {
  showoffSlides(slideIndex += n);
}

// Thumbnail image controls
function currentSlide(n) {
  showoffSlides(slideIndex = n);
}

function showoffSlides(n) {
  var j;
  var slides = document.getElementsByClassName("mySlides");
  var dots = document.getElementsByClassName("dot");
  if (n > slides.length) {slideIndex = 1}
  if (n < 1) {slideIndex = slides.length}
  for (j = 0; j < slides.length; j++) {
      slides[j].style.display = "none";
  }
  for (j = 0; j < dots.length; j++) {
      dots[j].className = dots[j].className.replace(" active", "");
  }
  slides[slideIndex-1].style.display = "block";
  dots[slideIndex-1].className += " active";
} 